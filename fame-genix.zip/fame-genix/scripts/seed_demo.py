"""
Seed demo users + one demo patient with a healthy baseline and a registered
FAME Mask simulator device. Run after the backend has started at least once
(so tables exist), or this script will create tables itself.

Usage:
    python scripts/seed_demo.py
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from app.db.models import (Device, DeviceStatus, DeviceType, Doctor, Patient,
                            Role, User)
from app.db.session import SessionLocal, init_db
from app.core.security import hash_password

DEMO_PASSWORD = "FameGenix#2026"

DEMO_USERS = [
    {"email": "patient@famegenix.demo", "role": Role.PATIENT, "full_name": "Demo Patient"},
    {"email": "doctor@famegenix.demo", "role": Role.DOCTOR, "full_name": "Dr. Demo"},
    {"email": "emergency@famegenix.demo", "role": Role.EMERGENCY_OPERATOR, "full_name": "Emergency Operator Demo"},
    {"email": "ambulance@famegenix.demo", "role": Role.AMBULANCE_TEAM, "full_name": "Ambulance Team Demo"},
    {"email": "admin@famegenix.demo", "role": Role.SYSTEM_ADMIN, "full_name": "System Admin Demo"},
]


def main():
    init_db()
    db = SessionLocal()
    try:
        created_patient_id = None

        for spec in DEMO_USERS:
            existing = db.query(User).filter(User.email == spec["email"]).first()
            if existing:
                print(f"[seed] {spec['email']} already exists, skipping.")
                if spec["role"] == Role.PATIENT:
                    p = db.query(Patient).filter(Patient.user_id == existing.id).first()
                    created_patient_id = p.id if p else created_patient_id
                continue

            user = User(email=spec["email"], password_hash=hash_password(DEMO_PASSWORD), role=spec["role"])
            db.add(user)
            db.flush()

            if spec["role"] == Role.PATIENT:
                patient = Patient(user_id=user.id, full_name=spec["full_name"], date_of_birth="2002-01-01",
                                   sex="unspecified", known_conditions="none",
                                   emergency_contact_name="Demo Contact", emergency_contact_phone="+91-9999999999")
                db.add(patient)
                db.flush()
                created_patient_id = patient.id
            elif spec["role"] == Role.DOCTOR:
                db.add(Doctor(user_id=user.id, full_name=spec["full_name"], specialty="General Medicine"))

            db.commit()
            print(f"[seed] created {spec['email']} ({spec['role']})")

        if created_patient_id:
            existing_device = db.query(Device).filter(Device.patient_id == created_patient_id,
                                                        Device.type == DeviceType.FAME_MASK).first()
            if not existing_device:
                device = Device(patient_id=created_patient_id, type=DeviceType.FAME_MASK,
                                 status=DeviceStatus.NOT_CONNECTED)
                db.add(device)
                db.commit()
                print(f"[seed] registered FAME_MASK device {device.id} for demo patient {created_patient_id}")
            else:
                print(f"[seed] demo device already exists: {existing_device.id}")

        print("\n[seed] Demo login credentials (all users):")
        for spec in DEMO_USERS:
            print(f"  {spec['email']} / {DEMO_PASSWORD}")

    finally:
        db.close()


if __name__ == "__main__":
    main()
