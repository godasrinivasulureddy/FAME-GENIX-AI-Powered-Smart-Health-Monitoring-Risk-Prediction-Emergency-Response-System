# Fame Genix — Hackathon Prototype

> **Disclaimer:** Fame Genix is a hackathon/research prototype for AI-assisted
> health monitoring and decision-support. It is **not** a medical diagnostic
> device and does **not** replace professional medical care. All device
> readings, ambulance dispatch, and hospital handoff in this build are
> **SIMULATED**.

## What's implemented (P0)

Auth+RBAC · patient profile · symptom intake + deterministic follow-ups ·
red-flag safety engine (versioned, deterministic) · personal baseline (per
patient **per metric**) · health drift engine (EWMA/slope) · anomaly scoring ·
synthetic/documented symptom-risk model · risk fusion (risk score, confidence
score, and care level kept **separate**) · FAME Mask device simulator with
4 scenarios · doctor priority queue + reviews · emergency case state machine
with full **trigger provenance** (rule/measurements/quality) · simulated
ambulance dispatch + hospital handoff · in-app notifications · append-only
audit log · patient timeline aggregating every event type.

**Not implemented** (documented stubs / future scope, see `quantum/README.md`
and architecture blueprint): QML, Gemini/LLM explanation layer, multilingual
voice input, OCR report extraction, image analysis, organization dashboard,
real BLE/hospital/ambulance integration.

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r backend/requirements.txt
```

Copy `backend/.env.example` to `backend/.env` if you want to override
defaults (Postgres URL, JWT secret, etc). **No `.env` is required** — SQLite
is used automatically, and the database file path is anchored to the
`backend/` folder regardless of which directory you run commands from.

## Seed demo data

```bash
python scripts/seed_demo.py
```

Creates 5 demo users (all password `FameGenix#2026`) and registers a FAME
Mask device for the demo patient:

| Email | Role |
|---|---|
| patient@famegenix.demo | PATIENT |
| doctor@famegenix.demo | DOCTOR |
| emergency@famegenix.demo | EMERGENCY_OPERATOR |
| ambulance@famegenix.demo | AMBULANCE_TEAM |
| admin@famegenix.demo | SYSTEM_ADMIN |

## Run the server

```bash
uvicorn app.main:app --app-dir backend --reload
```

API docs: **http://127.0.0.1:8000/docs**
Health check: **http://127.0.0.1:8000/health**

## Run tests

```bash
python -m pytest tests/ -v
```

12 tests covering auth/RBAC, baseline uniqueness (multi-metric per patient),
drift escalation, doctor queue placement, and the full emergency state
machine + audit trail.

## Demo flow (matches the required hackathon story)

1. Login as `patient@famegenix.demo`, `GET /api/v1/devices` to get your
   device id, `POST /api/v1/devices/{id}/connect`.
2. `POST /api/v1/simulator/start` with `scenario=CRITICAL_RESPIRATORY`.
3. Call `POST /api/v1/simulator/step` repeatedly (each call also
   auto-runs the risk pipeline) — watch `care_level` climb:
   `STABLE → MONITOR → PRIORITY_REVIEW → POSSIBLE_EMERGENCY`.
4. An emergency case is **auto-created** (`trigger_type=RULE`) once
   `care_level=POSSIBLE_EMERGENCY` is reached — check
   `GET /api/v1/emergency/cases` as `emergency@famegenix.demo`.
5. Login as `doctor@famegenix.demo`: `GET /api/v1/doctors/queue` shows the
   patient at the top; `POST /api/v1/doctors/reviews` to log a decision.
6. As `emergency@famegenix.demo`: `POST /api/v1/emergency/cases/{id}/verify`,
   then `/dispatch`, then optionally `/location`.
7. As `ambulance@famegenix.demo`: call `/advance` repeatedly to walk
   `DISPATCHED → PATIENT_REACHED → TRANSPORTING → HOSPITAL_REACHED → COMPLETED`.
8. `GET /api/v1/patients/{id}/timeline` (as the patient) shows every event in
   order. `GET /api/v1/audit/logs` (as admin) shows the full audit trail.

Full endpoint list is in `/docs` (Swagger UI) once the server is running.

## Architecture corrections applied in this build

- **Baseline uniqueness** fixed to `UNIQUE(patient_id, metric)` — a patient
  has many baseline metrics, not one (`app/db/models.py`).
- **Symptom risk model** uses a small, hand-authored, documented synthetic
  dataset (`app/risk/ml_model.py`) instead of an unvetted public
  symptom→disease dataset — narrow, reproducible, explicitly non-clinical.
- **Emergency provenance**: every case stores `trigger_type` (RULE / CLINICIAN
  / DEMO_SIMULATION), `trigger_rule_id`, `trigger_assessment_id`, a
  measurement snapshot, and measurement quality.
- Risk/confidence/care-level are always three separate fields — never merged.

## Known limitations / honest gaps

- Doctor↔patient authorization is currently role-based, not consent- or
  assignment-scoped (any DOCTOR can view any patient) — documented as a
  simplification for the hackathon window, not production-ready.
- SQLite is fine for the demo; switch `DATABASE_URL` to Postgres for anything
  beyond a single-process demo.
- WebSocket/live-push was **not** implemented — the frontend should poll
  (`GET /api/v1/doctors/queue`, `/notifications`) every few seconds instead.
