# Quantum ML Module — RESEARCH_ONLY (not implemented in this build)

Status: **RESEARCH_ONLY / placeholder**. Not wired into `risk_fusion` or any
production decision path, per architecture blueprint §K.

## Why not built now
P0 (the end-to-end patient→emergency demo loop) consumes the full hackathon
budget. QML was explicitly deprioritized in the roadmap and cut first if time
is short.

## Intended future shape
- Library: PennyLane.
- Candidate experiment: Variational Quantum Classifier or quantum-kernel
  classifier on a small (4–8 feature) subset of the same synthetic symptom
  dataset used by `backend/app/risk/ml_model.py`.
- Every run logged with: dataset, n_qubits, train/test split, backend
  (simulator), classical baseline reference, accuracy/precision/recall/F1/
  ROC-AUC, runtime, and explicit limitations — reported honestly even if the
  classical baseline wins.
- Exposed only via a dedicated `/qml-lab` surface; never mixed into patient
  or doctor risk output unless `ALLOW_QML=true` is explicitly set, and even
  then labeled EXPERIMENTAL in the UI.

## To implement later
Create `quantum/experiments/vqc_experiment.py` following the pattern in
`backend/app/risk/ml_model.py` (reproducible synthetic/documented dataset,
tracked metrics, no fabricated quantum-advantage claims).
