import json

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.assessments.schemas import CreateAssessmentRequest
from app.assessments.service import run_assessment
from app.core.dependencies import get_current_user, require_role
from app.core.exceptions import app_error
from app.core.response import ok
from app.db.models import RiskAssessment, RiskFactor, Role, User
from app.db.session import get_db
from app.patients.service import assert_can_view_patient, get_patient_by_user, get_patient_or_404

router = APIRouter(prefix="/api/v1/assessments", tags=["assessments"])


def _serialize(a: RiskAssessment) -> dict:
    return {
        "id": a.id, "patient_id": a.patient_id, "session_id": a.session_id,
        "risk_score": a.risk_score, "confidence_score": a.confidence_score,
        "care_level": a.care_level, "suggested_action": a.suggested_action,
        "missing_evidence": json.loads(a.missing_evidence or "[]"), "created_at": a.created_at,
    }


@router.post("")
def create_assessment(payload: CreateAssessmentRequest, user: User = Depends(require_role(Role.PATIENT)),
                       db: Session = Depends(get_db)):
    patient = get_patient_by_user(db, user)
    assessment = run_assessment(db, patient.id, payload.session_id)
    return ok(_serialize(assessment))


@router.get("/{assessment_id}")
def get_assessment(assessment_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.query(RiskAssessment).filter(RiskAssessment.id == assessment_id).first()
    if not a:
        raise app_error("NOT_FOUND", "Assessment not found.")
    patient = get_patient_or_404(db, a.patient_id)
    assert_can_view_patient(user, patient)
    return ok(_serialize(a))


@router.get("/{assessment_id}/explanation")
def get_explanation(assessment_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    a = db.query(RiskAssessment).filter(RiskAssessment.id == assessment_id).first()
    if not a:
        raise app_error("NOT_FOUND", "Assessment not found.")
    patient = get_patient_or_404(db, a.patient_id)
    assert_can_view_patient(user, patient)
    factors = db.query(RiskFactor).filter(RiskFactor.assessment_id == assessment_id).all()
    return ok({
        "assessment_id": a.id,
        "risk_score": a.risk_score, "confidence_score": a.confidence_score, "care_level": a.care_level,
        "factors": [{"factor_name": f.factor_name, "contribution": f.contribution, "direction": f.direction}
                    for f in factors],
    })


@router.get("/patient/{patient_id}")
def get_history(patient_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    patient = get_patient_or_404(db, patient_id)
    assert_can_view_patient(user, patient)
    rows = (
        db.query(RiskAssessment)
        .filter(RiskAssessment.patient_id == patient_id)
        .order_by(RiskAssessment.created_at.desc())
        .all()
    )
    return ok([_serialize(r) for r in rows])
