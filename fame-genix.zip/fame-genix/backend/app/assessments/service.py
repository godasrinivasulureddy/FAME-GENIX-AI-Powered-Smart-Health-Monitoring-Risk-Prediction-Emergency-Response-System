import json

from sqlalchemy.orm import Session

from app.core.events import RISK_ASSESSMENT_CREATED, DRIFT_DETECTED, event_bus
from app.db.models import (DeviceReading, DriftEvent, HealthScore,
                            RiskAssessment, RiskFactor, SymptomEntry,
                            SymptomSession)
from app.risk.anomaly import compute_anomaly_score
from app.risk.baseline import update_baseline
from app.risk.drift import compute_drift
from app.risk.fusion import fuse_risk
from app.risk.ml_model import predict_risk

TRACKED_METRICS = ["heart_rate", "spo2", "respiratory_rate", "temperature", "voc_index"]
SEVERITY_MAP = {"mild": 0, "moderate": 1, "severe": 2}


def _latest_value(db: Session, patient_id: str, metric: str) -> float | None:
    r = (
        db.query(DeviceReading)
        .filter(DeviceReading.patient_id == patient_id, DeviceReading.metric == metric)
        .order_by(DeviceReading.recorded_at.desc())
        .first()
    )
    return r.value if r else None


def _spo2_drop_rate(db: Session, patient_id: str) -> float:
    readings = (
        db.query(DeviceReading)
        .filter(DeviceReading.patient_id == patient_id, DeviceReading.metric == "spo2")
        .order_by(DeviceReading.recorded_at.desc())
        .limit(2)
        .all()
    )
    if len(readings) < 2:
        return 0.0
    latest, previous = readings[0].value, readings[1].value
    return max(0.0, previous - latest)


def run_assessment(db: Session, patient_id: str, session_id: str | None = None) -> RiskAssessment:
    # --- symptom features (default to 0 if no session provided) ---
    symptom_count, max_severity, duration_hours, red_flag_count = 0, 0, 0.0, 0
    concepts: list[str] = []
    breathing_difficulty = chest_pain_severe = dizziness = bleeding = False

    session = None
    if session_id:
        session = db.query(SymptomSession).filter(SymptomSession.id == session_id).first()
    if not session:
        session = (
            db.query(SymptomSession)
            .filter(SymptomSession.patient_id == patient_id)
            .order_by(SymptomSession.created_at.desc())
            .first()
        )

    if session:
        entries = db.query(SymptomEntry).filter(SymptomEntry.session_id == session.id).all()
        concepts = [e.concept for e in entries]
        symptom_count = len(concepts)
        for e in entries:
            max_severity = max(max_severity, SEVERITY_MAP.get(e.severity or "mild", 0))
            duration_hours = max(duration_hours, e.duration_hours or 0.0)
        breathing_difficulty = "breathing_difficulty" in concepts
        chest_pain_severe = "chest_pain" in concepts and max_severity == 2
        dizziness = "dizziness" in concepts
        bleeding = "bleeding" in concepts
        red_flag_count = sum([breathing_difficulty, chest_pain_severe, dizziness, bleeding])

    ml_risk = predict_risk(symptom_count, max_severity, duration_hours, red_flag_count)

    # --- device-derived signals ---
    modalities_present = 1 if session else 0
    metrics_with_data = [m for m in TRACKED_METRICS if _latest_value(db, patient_id, m) is not None]
    if metrics_with_data:
        modalities_present += 1

    anomaly = compute_anomaly_score(db, patient_id, metrics_with_data)
    drift = compute_drift(db, patient_id, metrics_with_data)

    if drift["severity"] != "none":
        drift_event = DriftEvent(
            patient_id=patient_id, drift_score=drift["drift_score"], direction=drift["direction"],
            severity=drift["severity"], contributing_metrics=json.dumps(drift["contributing_metrics"]),
        )
        db.add(drift_event)
        db.commit()
        event_bus.publish(DRIFT_DETECTED, {"patient_id": patient_id, "drift": drift})

    safety_context = {
        "spo2": _latest_value(db, patient_id, "spo2"),
        "spo2_drop_rate": _spo2_drop_rate(db, patient_id),
        "heart_rate": _latest_value(db, patient_id, "heart_rate"),
        "breathing_difficulty_reported": breathing_difficulty,
        "chest_pain_severe": chest_pain_severe,
        "dizziness_or_unconscious": dizziness,
        "severe_bleeding_reported": bleeding,
    }

    fused = fuse_risk(
        ml_risk=ml_risk,
        anomaly_score=anomaly["anomaly_score"],
        drift_score=drift["drift_score"],
        safety_context=safety_context,
        modalities_present=modalities_present,
    )

    assessment = RiskAssessment(
        patient_id=patient_id,
        session_id=session.id if session else None,
        risk_score=fused["risk_score"],
        confidence_score=fused["confidence_score"],
        care_level=fused["care_level"],
        suggested_action=fused["suggested_action"],
        missing_evidence=json.dumps(fused["missing_evidence"]),
    )
    db.add(assessment)
    db.flush()

    for factor in fused["top_factors"]:
        db.add(RiskFactor(assessment_id=assessment.id, factor_name=factor["factor_name"],
                           contribution=factor["contribution"], direction=factor["direction"]))

    health_score_value = max(0.0, 100.0 - fused["risk_score"])
    db.add(HealthScore(patient_id=patient_id, score=round(health_score_value, 2)))

    db.commit()
    db.refresh(assessment)

    event_bus.publish(RISK_ASSESSMENT_CREATED, {
        "patient_id": patient_id, "assessment_id": assessment.id,
        "risk_score": assessment.risk_score, "confidence_score": assessment.confidence_score,
        "care_level": assessment.care_level, "triggered_safety_rules": fused["triggered_safety_rules"],
        "safety_context": safety_context,
    })

    return assessment
