from app.core.events import RISK_ASSESSMENT_CREATED, event_bus
from app.db.models import CareLevel, EmergencyCase
from app.db.session import SessionLocal
from app.emergency.service import create_case


def _on_risk_assessment_created(payload: dict) -> None:
    if payload.get("care_level") != CareLevel.POSSIBLE_EMERGENCY:
        return

    db = SessionLocal()
    try:
        # Avoid duplicate auto-cases: skip if patient already has a non-terminal case.
        existing = (
            db.query(EmergencyCase)
            .filter(EmergencyCase.patient_id == payload["patient_id"])
            .filter(EmergencyCase.status.notin_(["COMPLETED", "CANCELLED"]))
            .first()
        )
        if existing:
            return

        triggered_rules = payload.get("triggered_safety_rules") or []
        rule_id = triggered_rules[0]["rule_id"] if triggered_rules else None

        create_case(
            db, patient_id=payload["patient_id"], trigger_type="RULE",
            severity="POSSIBLE_EMERGENCY", trigger_rule_id=rule_id,
            trigger_assessment_id=payload.get("assessment_id"),
        )
    finally:
        db.close()


def register_subscribers() -> None:
    event_bus.subscribe(RISK_ASSESSMENT_CREATED, _on_risk_assessment_created)
