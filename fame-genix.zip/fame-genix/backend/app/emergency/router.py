import json

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.audit.helper import record_audit
from app.core.dependencies import require_role
from app.core.response import ok
from app.db.models import (AmbulanceAssignment, EmergencyCase, HospitalHandoff,
                            Patient, Role)
from app.db.session import get_db
from app.emergency.schemas import CreateEmergencyRequest, LocationRequest
from app.emergency.service import (advance, attach_location, create_case,
                                    get_case_or_404, request_dispatch, verify)
from app.doctors.service import latest_vitals

router = APIRouter(prefix="/api/v1/emergency", tags=["emergency"])
ambulance_router = APIRouter(prefix="/api/v1/ambulance", tags=["ambulance"])


def _serialize(case: EmergencyCase) -> dict:
    return {
        "id": case.id, "patient_id": case.patient_id, "status": case.status, "severity": case.severity,
        "trigger_type": case.trigger_type, "trigger_rule_id": case.trigger_rule_id,
        "trigger_assessment_id": case.trigger_assessment_id,
        "trigger_measurements": json.loads(case.trigger_measurements or "{}"),
        "measurement_quality": case.measurement_quality,
        "simulation_status": case.simulation_status,
        "location": {"lat": case.latitude, "lng": case.longitude, "consent": case.location_consent},
        "created_at": case.created_at, "updated_at": case.updated_at,
    }


@router.post("/cases")
def create_emergency_case(payload: CreateEmergencyRequest,
                           user=Depends(require_role(Role.DOCTOR, Role.EMERGENCY_OPERATOR)),
                           db: Session = Depends(get_db)):
    case = create_case(db, payload.patient_id, trigger_type=payload.trigger_type)
    record_audit(db, user.id, user.role, "EMERGENCY_CASE_CREATED", "patient", payload.patient_id,
                 metadata={"case_id": case.id, "trigger_type": payload.trigger_type})
    return ok(_serialize(case))


@router.get("/cases")
def list_cases(user=Depends(require_role(Role.EMERGENCY_OPERATOR, Role.DOCTOR)), db: Session = Depends(get_db)):
    cases = db.query(EmergencyCase).order_by(EmergencyCase.created_at.desc()).all()
    return ok([_serialize(c) for c in cases])


@router.get("/cases/{case_id}")
def get_case(case_id: str, user=Depends(require_role(Role.EMERGENCY_OPERATOR, Role.DOCTOR, Role.AMBULANCE_TEAM)),
             db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    return ok(_serialize(case))


@router.post("/cases/{case_id}/verify")
def verify_case(case_id: str, user=Depends(require_role(Role.EMERGENCY_OPERATOR, Role.DOCTOR)),
                 db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    case = verify(db, case, user.id)
    record_audit(db, user.id, user.role, "EMERGENCY_VERIFIED", "emergency_case", case_id)
    return ok(_serialize(case))


@router.post("/cases/{case_id}/dispatch")
def dispatch_case(case_id: str, user=Depends(require_role(Role.EMERGENCY_OPERATOR)), db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    case = request_dispatch(db, case)
    record_audit(db, user.id, user.role, "DISPATCH_REQUESTED", "emergency_case", case_id)
    return ok(_serialize(case))


@router.post("/cases/{case_id}/advance")
def advance_case(case_id: str, user=Depends(require_role(Role.EMERGENCY_OPERATOR, Role.AMBULANCE_TEAM)),
                  db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    case = advance(db, case)
    record_audit(db, user.id, user.role, "AMBULANCE_ADVANCE", "emergency_case", case_id,
                 metadata={"new_status": case.status})
    return ok(_serialize(case))


@router.post("/cases/{case_id}/location")
def set_location(case_id: str, payload: LocationRequest,
                  user=Depends(require_role(Role.PATIENT, Role.EMERGENCY_OPERATOR, Role.DOCTOR)),
                  db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    case = attach_location(db, case, payload.latitude, payload.longitude, payload.accuracy, payload.consent)
    record_audit(db, user.id, user.role, "LOCATION_ACCESS", "emergency_case", case_id)
    return ok(_serialize(case))


# --------------------------- Ambulance sub-domain --------------------------
@ambulance_router.get("/assigned")
def assigned_cases(user=Depends(require_role(Role.AMBULANCE_TEAM)), db: Session = Depends(get_db)):
    assignments = db.query(AmbulanceAssignment).filter(
        AmbulanceAssignment.status.notin_(["COMPLETED"])
    ).all()
    cases = []
    for a in assignments:
        case = db.query(EmergencyCase).filter(EmergencyCase.id == a.case_id).first()
        if case:
            cases.append(_serialize(case))
    return ok(cases)


@ambulance_router.get("/cases/{case_id}/brief")
def patient_brief(case_id: str, user=Depends(require_role(Role.AMBULANCE_TEAM, Role.EMERGENCY_OPERATOR)),
                   db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    patient = db.query(Patient).filter(Patient.id == case.patient_id).first()
    return ok({
        "case_id": case.id,
        "patient_pseudonymous_id": f"FG-P-{patient.id[:8]}" if patient else "unknown",
        "primary_alert": case.severity,
        "latest_measurements": json.loads(case.trigger_measurements or "{}"),
        "known_conditions": patient.known_conditions if patient else None,
        "emergency_contact": {"name": patient.emergency_contact_name, "phone": patient.emergency_contact_phone}
                              if patient else None,
        "location": {"lat": case.latitude, "lng": case.longitude},
    })


@ambulance_router.post("/cases/{case_id}/status")
def update_status(case_id: str, user=Depends(require_role(Role.AMBULANCE_TEAM)), db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    case = advance(db, case)
    return ok(_serialize(case))
