from datetime import datetime

from pydantic import BaseModel


class PatientUpdate(BaseModel):
    full_name: str | None = None
    date_of_birth: str | None = None
    sex: str | None = None
    known_conditions: str | None = None
    family_history: str | None = None
    emergency_contact_name: str | None = None
    emergency_contact_phone: str | None = None


class PatientOut(BaseModel):
    id: str
    full_name: str
    date_of_birth: str | None = None
    sex: str | None = None
    known_conditions: str | None = None
    family_history: str | None = None
    emergency_contact_name: str | None = None
    emergency_contact_phone: str | None = None

    class Config:
        from_attributes = True


class TimelineEvent(BaseModel):
    type: str
    timestamp: datetime
    summary: str
    data: dict
