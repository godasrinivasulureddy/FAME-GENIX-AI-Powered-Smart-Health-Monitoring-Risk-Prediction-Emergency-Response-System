from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.dependencies import get_current_user, require_role
from app.core.response import ok
from app.db.models import HealthScore, Role, User
from app.db.session import get_db
from app.patients.schemas import PatientOut, PatientUpdate
from app.patients.service import (assert_can_view_patient, build_timeline,
                                   get_patient_by_user, get_patient_or_404)

router = APIRouter(prefix="/api/v1/patients", tags=["patients"])


@router.get("/me")
def get_me(user: User = Depends(require_role(Role.PATIENT)), db: Session = Depends(get_db)):
    patient = get_patient_by_user(db, user)
    return ok(PatientOut.model_validate(patient).model_dump())


@router.put("/me")
def update_me(payload: PatientUpdate, user: User = Depends(require_role(Role.PATIENT)),
              db: Session = Depends(get_db)):
    patient = get_patient_by_user(db, user)
    for field, value in payload.model_dump(exclude_unset=True).items():
        setattr(patient, field, value)
    db.commit()
    db.refresh(patient)
    return ok(PatientOut.model_validate(patient).model_dump())


@router.get("/{patient_id}")
def get_patient(patient_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    patient = get_patient_or_404(db, patient_id)
    assert_can_view_patient(user, patient)
    return ok(PatientOut.model_validate(patient).model_dump())


@router.get("/{patient_id}/timeline")
def get_timeline(patient_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    patient = get_patient_or_404(db, patient_id)
    assert_can_view_patient(user, patient)
    return ok({"patient_id": patient_id, "events": build_timeline(db, patient_id)})


@router.get("/{patient_id}/health-summary")
def get_health_summary(patient_id: str, user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    patient = get_patient_or_404(db, patient_id)
    assert_can_view_patient(user, patient)
    latest_score = (
        db.query(HealthScore)
        .filter(HealthScore.patient_id == patient_id)
        .order_by(HealthScore.computed_at.desc())
        .first()
    )
    return ok({
        "patient_id": patient_id,
        "wellness_score": latest_score.score if latest_score else None,
        "label": "Fame Genix Prototype Health Stability Score (not a clinical diagnosis)",
        "computed_at": latest_score.computed_at if latest_score else None,
    })
