from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.audit.helper import record_audit
from app.core.dependencies import require_role
from app.core.events import DOCTOR_REVIEW_COMPLETED, event_bus
from app.core.exceptions import app_error
from app.core.response import ok
from app.db.models import Doctor, DoctorReview, Role, User
from app.db.session import get_db
from app.doctors.schemas import EscalateRequest, ReviewRequest
from app.doctors.service import build_queue, latest_vitals
from app.patients.service import build_timeline, get_patient_or_404
from app.db.models import RiskAssessment, RiskFactor

router = APIRouter(prefix="/api/v1/doctors", tags=["doctors"])


def _get_doctor(db: Session, user: User) -> Doctor:
    doctor = db.query(Doctor).filter(Doctor.user_id == user.id).first()
    if not doctor:
        raise app_error("NOT_FOUND", "Doctor profile not found for current user.")
    return doctor


@router.get("/queue")
def get_queue(user: User = Depends(require_role(Role.DOCTOR)), db: Session = Depends(get_db)):
    return ok(build_queue(db))


@router.get("/patients/{patient_id}")
def get_patient_view(patient_id: str, user: User = Depends(require_role(Role.DOCTOR)), db: Session = Depends(get_db)):
    patient = get_patient_or_404(db, patient_id)
    latest = (
        db.query(RiskAssessment)
        .filter(RiskAssessment.patient_id == patient_id)
        .order_by(RiskAssessment.created_at.desc())
        .first()
    )
    factors = []
    if latest:
        factors = db.query(RiskFactor).filter(RiskFactor.assessment_id == latest.id).all()
    reviews = db.query(DoctorReview).filter(DoctorReview.patient_id == patient_id).all()

    return ok({
        "patient": {"id": patient.id, "full_name": patient.full_name,
                    "known_conditions": patient.known_conditions},
        "latest_assessment": None if not latest else {
            "id": latest.id, "risk_score": latest.risk_score, "confidence_score": latest.confidence_score,
            "care_level": latest.care_level, "suggested_action": latest.suggested_action,
        },
        "explanation_factors": [{"factor_name": f.factor_name, "contribution": f.contribution,
                                  "direction": f.direction} for f in factors],
        "latest_vitals": latest_vitals(db, patient_id),
        "previous_reviews": [{"id": r.id, "decision": r.decision, "note": r.note, "created_at": r.created_at}
                              for r in reviews],
        "timeline": build_timeline(db, patient_id),
    })


@router.post("/reviews")
def add_review(payload: ReviewRequest, user: User = Depends(require_role(Role.DOCTOR)), db: Session = Depends(get_db)):
    doctor = _get_doctor(db, user)
    review = DoctorReview(doctor_id=doctor.id, patient_id=payload.patient_id,
                           assessment_id=payload.assessment_id, note=payload.note, decision=payload.decision)
    db.add(review)
    db.commit()
    db.refresh(review)

    record_audit(db, user.id, user.role, "DOCTOR_REVIEW", "patient", payload.patient_id,
                 metadata={"decision": payload.decision, "review_id": review.id})
    event_bus.publish(DOCTOR_REVIEW_COMPLETED, {"patient_id": payload.patient_id, "decision": payload.decision,
                                                 "doctor_id": doctor.id, "review_id": review.id})
    return ok({"id": review.id, "decision": review.decision, "created_at": review.created_at})


@router.post("/escalate")
def escalate(payload: EscalateRequest, user: User = Depends(require_role(Role.DOCTOR)), db: Session = Depends(get_db)):
    doctor = _get_doctor(db, user)
    review = DoctorReview(doctor_id=doctor.id, patient_id=payload.patient_id, note=payload.note,
                           decision="URGENT_REVIEW")
    db.add(review)
    db.commit()
    record_audit(db, user.id, user.role, "ESCALATE", "patient", payload.patient_id)
    return ok({"patient_id": payload.patient_id, "decision": "URGENT_REVIEW"})


@router.post("/deescalate")
def deescalate(payload: EscalateRequest, user: User = Depends(require_role(Role.DOCTOR)), db: Session = Depends(get_db)):
    doctor = _get_doctor(db, user)
    review = DoctorReview(doctor_id=doctor.id, patient_id=payload.patient_id, note=payload.note,
                           decision="MONITOR")
    db.add(review)
    db.commit()
    record_audit(db, user.id, user.role, "DEESCALATE", "patient", payload.patient_id)
    return ok({"patient_id": payload.patient_id, "decision": "MONITOR"})
