"""
Deterministic keyword -> symptom-concept extraction and follow-up question
rules. Intentionally simple and inspectable (no LLM dependency) so the core
pipeline works without any external API key.
"""

SYMPTOM_KEYWORDS = {
    "fever": ["fever", "temperature", "hot", "chills"],
    "cough": ["cough", "coughing"],
    "breathing_difficulty": ["breathless", "breathing difficulty", "shortness of breath", "cant breathe",
                              "can't breathe", "difficulty breathing"],
    "chest_pain": ["chest pain", "chest tightness"],
    "headache": ["headache", "head pain"],
    "vomiting": ["vomit", "vomiting", "throwing up"],
    "rash": ["rash", "skin spots"],
    "bleeding": ["bleeding", "blood loss"],
    "joint_pain": ["joint pain", "body pain", "ache"],
    "dizziness": ["dizzy", "dizziness", "fainting", "unconscious"],
}

# concept -> list of (question, reason) if missing info
FOLLOWUP_RULES = {
    "fever": [
        ("How long have you had the fever (in hours)?", "Duration affects urgency and drift comparison."),
        ("Is the fever mild, moderate, or severe?", "Severity affects risk weighting."),
        ("Do you also have a rash?", "Rash + fever can indicate higher-priority conditions."),
        ("Do you have vomiting?", "Vomiting alongside fever changes risk profile."),
        ("Do you have breathing difficulty?", "Red-flag screening requires this explicitly."),
    ],
    "cough": [
        ("How long have you had the cough (in hours)?", "Duration affects urgency."),
        ("Is there breathing difficulty with the cough?", "Red-flag screening."),
        ("Is the cough severe?", "Severity affects risk weighting."),
    ],
    "headache": [
        ("Is the headache severe or sudden-onset?", "Red-flag screening for severe headache."),
        ("Do you have dizziness or vision changes?", "Additional red-flag context."),
    ],
}


def extract_concepts(raw_text: str) -> list[str]:
    text = raw_text.lower()
    found = []
    for concept, keywords in SYMPTOM_KEYWORDS.items():
        if any(kw in text for kw in keywords):
            found.append(concept)
    return found


def generate_followups(concepts: list[str]) -> list[tuple[str, str]]:
    questions: list[tuple[str, str]] = []
    for c in concepts:
        questions.extend(FOLLOWUP_RULES.get(c, []))
    # de-duplicate while preserving order
    seen = set()
    unique = []
    for q, r in questions:
        if q not in seen:
            seen.add(q)
            unique.append((q, r))
    return unique
