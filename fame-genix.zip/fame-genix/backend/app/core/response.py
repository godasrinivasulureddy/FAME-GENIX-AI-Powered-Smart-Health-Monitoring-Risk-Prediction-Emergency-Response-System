from typing import Any


def ok(data: Any) -> dict:
    return {"data": data, "error": None}
