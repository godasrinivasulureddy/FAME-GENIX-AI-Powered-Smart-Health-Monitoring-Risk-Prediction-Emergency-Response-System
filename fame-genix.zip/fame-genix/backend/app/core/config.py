import os
from pydantic_settings import BaseSettings

# Anchor the default SQLite file to the backend/ directory (parent of app/),
# NOT the process's current working directory. Without this, running the
# server from backend/ and a script from the repo root silently creates two
# different database files.
_BACKEND_DIR = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_DEFAULT_SQLITE_PATH = os.path.join(_BACKEND_DIR, "fame_genix.db")


class Settings(BaseSettings):
    APP_NAME: str = "Fame Genix"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    DEMO_MODE: bool = os.getenv("DEMO_MODE", "true").lower() == "true"

    DATABASE_URL: str = os.getenv("DATABASE_URL", f"sqlite:///{_DEFAULT_SQLITE_PATH}")

    JWT_SECRET: str = os.getenv("JWT_SECRET", "dev-secret-change-me")
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30
    REFRESH_TOKEN_EXPIRE_MINUTES: int = 60 * 24 * 7

    ALLOW_QML: bool = False

    class Config:
        env_file = ".env"


settings = Settings()
